#include <bits/stdc++.h>
#include<iostream>
#include "clients.cpp"
using namespace std;

class Restaurant
{
private:
    string name;
    // Menu* order;
    // int nrOfOrders;
    vector<Menu> order;
    // Clients* clients;
    // int nrOfClients;
    set<Clients> clients;

public:
    Restaurant()
    {
        this->name = "NoName";
    }

    Restaurant(string name)
    {
        if(name.length() > 0)
            this->name = name;
        
    }

    Restaurant(string name, vector<Menu>& order, set<Clients>& clients)
    {
        if(name.length() > 0){
            this->name = name;
        }else
            this->name = "NoName";  
        if(!order.empty()){
            this->order = order;
        }else
            this->order.clear();
        if(!clients.empty()){
            this->clients = clients;
        }else
            this->clients.clear();
    }

    Restaurant(const Restaurant& restaurant)
    {
        if(restaurant.name.length() > 0){
            this->name = restaurant.name;
        }
        if(!restaurant.order.empty()){
            this->order = restaurant.order;
        }else
            this->order.clear();
        if(!restaurant.clients.empty()){
            this->clients = restaurant.clients;
        }else
            this->clients.clear();
    }

    Restaurant& operator=(const Restaurant& restaurant)
    {
        if(this != &restaurant) {            
            if(restaurant.name.length() > 0){
                this->name = restaurant.name;
            }
            if(!restaurant.order.empty()){
                this->order = restaurant.order;
            }else
                this->order.clear();
            if(!restaurant.clients.empty()){
                this->clients = restaurant.clients;
            }else
                this->clients.clear();
            }
        return *this;        
    }

    string getName() {
        return this->name;
    }

    void setName(string newName) {
        if(newName.length() > 0){
            this->name = newName;
        }
    }

    vector<Menu>& getOrder() {
        return this->order;
    }
    void setOrder(vector<Menu>& newOrder) {
        this->order = newOrder;
    }
    set<Clients>& getClients() {
        return this->clients;
    }
    void setClients(set<Clients>& newClients) {
        this->clients = newClients;
    }

    friend ostream &operator<<(ostream &out, const Restaurant &restaurant)
    {
        out << "\n Name: " << restaurant.name << endl;
        out << "\n Number of orders: " << restaurant.order.size() << endl;
        out<<"\n Order: ";
        if(!restaurant.order.empty()){
            for (const auto &menu : restaurant.order)
            {
                out << menu << " ";
            }
        }
        else{
            out << "No order";
        }
        out << "\n Number of clients: " << restaurant.clients.size() << endl;
        out << "\n Clients: ";
        for (const auto &client : restaurant.clients) {
            out << client << endl;
        }
        return out;
    }

    friend ofstream &operator<<(ofstream &out, const Restaurant &restaurant)
    {
        out << "\n Name: " << restaurant.name << endl;
        out << "\n Number of orders: " << restaurant.order.size() << endl;
        out<<"\n Order: ";
        if(!restaurant.order.empty()){
            for (const auto &menu : restaurant.order)
            {
                out << menu << " ";
            }
        }
        else{
            out << "No order";
        }
        out << "\n Number of clients: " << restaurant.clients.size() << endl;
        out << "\n Clients: ";
        for (const auto &client : restaurant.clients) {
            out << client << endl;
        }
        return out;
    }

    friend istream &operator>>(istream &in, Restaurant &restaurant)
    {
        cin.ignore();
        cout <<"\n Name";
        getline(in, restaurant.name);
        restaurant.order.clear();

        cout << "\n Number of orders: ";
        int nrOfOrders = restaurant.order.size();
        in >> nrOfOrders;   
        if(nrOfOrders < 0){
            nrOfOrders = 0;
            restaurant.order.clear();
        }else{
            for(int i = 0; i < nrOfOrders; i++){
                cout << "\n Order name: " << i + 1 << ")";
                Menu menu;
                in >> menu;
                restaurant.order.push_back(menu);
            }
        }
        restaurant.clients.clear();
        cout<<"\n Number of clients: ";
        int nrOfClients = restaurant.clients.size();
        in >> nrOfClients;
        restaurant.clients.clear();

        if(nrOfClients < 0){
            nrOfClients = 0;
            restaurant.clients.clear();
        }else{
            for(int i = 0; i < nrOfClients; i++){
                cout << "\n Client name: " << i + 1 << ")";
                Clients client;
                in >> client;
                restaurant.clients.insert(client);
            }
        }
    }
    
     friend ifstream &operator>>(ifstream &in, Restaurant &restaurant)
    {
        cin.ignore();
        cout <<"\n Name";
        getline(in, restaurant.name);
        restaurant.order.clear();

        cout << "\n Number of orders: ";
        int nrOfOrders = restaurant.order.size();
        in >> nrOfOrders;   
        if(nrOfOrders < 0){
            nrOfOrders = 0;
            restaurant.order.clear();
        }else{
            for(int i = 0; i < nrOfOrders; i++){
                cout << "\n Order name: " << i + 1 << ")";
                Menu menu;
                in >> menu;
                restaurant.order.push_back(menu);
            }
        }
        restaurant.clients.clear();
        cout<<"\n Number of clients: ";
        int nrOfClients = restaurant.clients.size();
        in >> nrOfClients;
        restaurant.clients.clear();

        if(nrOfClients < 0){
            nrOfClients = 0;
            restaurant.clients.clear();
        }else{
            for(int i = 0; i < nrOfClients; i++){
                cout << "\n Client name: " << i + 1 << ")";
                Clients client;
                in >> client;
                restaurant.clients.insert(client);
            }
        }
    }
    ~Restaurant() {}
};
