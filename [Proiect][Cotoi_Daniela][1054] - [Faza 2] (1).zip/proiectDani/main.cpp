#include <bits/stdc++.h>
#include "restaurant.cpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <list>

using namespace std;
                                                                                                                                                                                                                        
struct User {
    string name;
    string email;
    string phoneNumber;

    User(const string& n, const string& e, const string& phone) : name(n), email(e), phoneNumber(phone) {}
};


    int main(int argc, char *argv[])
    {   
        // Vector for storing meals
        vector<Meal> meals;
        vector<Clients> allClients;  // Vector pentru a stoca toți clienții

        cout<<"\n Welcome to my restaurant";
        while(true)
        {
            cout <<"\n Write command to see the list of commands: ";
            string command;
            cin >> command;

            if (command == "command")
            {
                cout << "\n ------ What are you interested in ?-----";
                cout << "\n 1).Menu (our meals)";
                cout << "\n 2).Add_order ";
                cout << "\n 3).RaportIng (raports about the stock of ingredients)";
                cout << "\n 4).RaportCl (clients list)";
                cout <<"\n 5). RaportQes (the most common questions from clients)";
                cout << "\n 5).Quit";
            }
            else
                if (command == "Add_order") 
                    {
                        vector<Clients> allClients;  // Vector pentru a stoca toți clienții

                        // Deschide fisierul binar in mod append
                        ofstream clientBinFile("client.bin", ios::binary | ios::app);
                        
                        // Deschide fisierul text in mod append
                        ofstream clientsFile("clients.txt", ios::app);

                        cout << "\n Please enter your full name: ";
                        cin.ignore();
                        string clientName;
                        getline(cin, clientName);

                        // Ask for the number of meals the client wants to order
                        cout << "\n How many meals would you like to order? ";
                        int numMeals;
                        cin >> numMeals;
                        cin.ignore(); // Consuma caracterul newline

                        // Iterate to get details for each meal
                        for (int i = 0; i < numMeals; ++i) 
                        {
                            bool found = false;

                            cout << "\n Enter details for meal " << i + 1 << ":" << endl;
                            string orderName;

                            do 
                            {
                                cout << " What would you like to order? ";
                                getline(cin, orderName);

                                // Reading from the file
                                ifstream menuFile("menu.txt");
                                string menuLine;
                                
                                while (getline(menuFile, menuLine)) {
                                    // Găsește poziția primei virgule
                                    size_t commaPos = menuLine.find(',');

                                    // Extragerea primului cuvânt din linie (până la prima virgulă sau până la sfârșitul liniei)
                                    string menuCommand = menuLine.substr(0, commaPos);

                                    // Compare with the order entered from the keyboard
                                    if (orderName == menuCommand) {
                                        found = true;
                                        break;  // Exit the while loop if a match is found
                                    }
                                }
                                menuFile.close();

                                // Display the result
                                if (found == true) {
                                    cout << "\n Your order is in the menu. Placing the order..." << endl;

                                    // Adaugă comanda in fisierul text
                                    clientsFile << "\nClient name: " << clientName;
                                    clientsFile << "\nOrder name: " << orderName << endl;

                                    // Adaugă comanda in fisierul binar
                                    Clients client;
                                    client.setName(clientName);

                                    // Creează o listă goală de ingrediente
                                    list<Ingredient> emptyIngredients;
                                    Meal meal(orderName, "", 0, 0, emptyIngredients);  // Meal fictiv, deoarece avem nevoie doar de numele preparatului
                                    client.getOrderP().push_back(meal);  // Adaugă direct la vectorul meals al obiectului client
                                    client.writeToFile(clientBinFile);
                                    allClients.push_back(client);
                                } 
                                else {
                                    cout << "\n Sorry, the entered order is not in the menu." << endl;
                                    cout << " Do you want to order something else? (y/n): ";
                                    char response;
                                    cin >> response;

                                    if (response != 'y' && response != 'Y') {
                                        break;  // Exit the do-while loop if the user doesn't want to order anything else
                                    }
                                    // Consume the newline character in the buffer
                                    cin.ignore();
                                }

                            } while (!found);
                        }

                            // Close the binary file stream
                            clientBinFile.close();
                            // Close the main clientsFile stream after all orders are processed
                            clientsFile.close();
                            } else 
                                if(command == "Menu")
                                {
                                    ifstream myfile("menu.txt");
                                    string mystring;

                                    getline(myfile, mystring);
                                    int nrOfMeals = atoi(mystring.c_str());

                                    while (nrOfMeals > 0) {
                                    getline(myfile, mystring);
                                    // cout << nrOfMeals << " : " << mystring << endl;

                                    string name = strtok(&mystring[0], ",");
                                    string description = strtok(NULL, ",");
                                    float price = atof(strtok(NULL, ","));
                                    int quantity = atoi(strtok(NULL, ","));

                                    //Reads the number of ingredients
                                    int nrOfIngredients = atoi(strtok(NULL, ","));

                                    //cout << name << " " << description << " " << price << " " << quantity << " " << nrOfIngredients << endl;

                                    // Read and add ingredients to the list
                                    list<Ingredient> ingredients;
                                    for (int i = 0; i < nrOfIngredients; i++) {
                                        string ingredientName = strtok(NULL, ",");
                                        int ingredientQuantity = atoi(strtok(NULL, ","));
                                        int ingredientStock = atoi(strtok(NULL, ","));

                                        //cout << ingredientName << " " << ingredientQuantity << " " << ingredientStock << endl;

                                        ingredients.push_back(Ingredient(ingredientName, ingredientQuantity, ingredientStock));
                                        }

                                    // Creating the object for Meal
                                    Meal meal(name, description, price, quantity, ingredients);
                                    cout << meal;

                                    nrOfMeals--;
                                    }
                                    myfile.close();
                                } else
                                    if(command == "RaportIng")
                                    {
                                        vector<Ingredient> allIngredients;
                                        ifstream myfile("menu.txt");
                                        ofstream ingredientsFile("Mealsingredients.txt"); // Deschide fișierul pentru a scrie

                                        if (!ingredientsFile.is_open()) {
                                            cerr << "Unable to open Mealsingredients.txt for writing." << endl;
                                            return 1; // Returnează cod de eroare
                                        }

                                        string mystring;

                                        getline(myfile, mystring);
                                        int nrOfMeals = atoi(mystring.c_str());

                                        while (nrOfMeals > 0) {
                                            getline(myfile, mystring);

                                            string name = strtok(&mystring[0], ",");
                                            string description = strtok(NULL, ",");
                                            float price = atof(strtok(NULL, ","));
                                            int quantity = atoi(strtok(NULL, ","));

                                            int nrOfIngredients = atoi(strtok(NULL, ","));

                                            list<Ingredient> ingredients;
                                            for (int i = 0; i < nrOfIngredients; i++) {
                                                string ingredientName = strtok(NULL, ",");
                                                int ingredientQuantity = atoi(strtok(NULL, ","));
                                                int ingredientStock = atoi(strtok(NULL, ","));

                                                ingredients.push_back(Ingredient(ingredientName, ingredientQuantity, ingredientStock));

                                                // Adaugă ingredientele la lista globală
                                                allIngredients.push_back(Ingredient(ingredientName, ingredientQuantity, ingredientStock));
                                            }

                                            // Afișează lista de ingrediente înainte de a scrie în fișier
                                            cout << "Ingredients for " << name << ": ";
                                            for (const auto& ingredient : ingredients) {
                                                cout << ingredient.getName() << ", ";
                                            }
                                            cout << endl;

                                            ingredientsFile << "Ingredients for " << name << ": ";
                                            for (const auto& ingredient : ingredients) {
                                                ingredientsFile << ingredient.getName() << ", ";
                                            }
                                            ingredientsFile << endl;

                                            nrOfMeals--;
                                        }

                                        myfile.close();
                                        ingredientsFile.close(); // Închide fișierul

                                        // Afisează toate ingredientele
                                        cout << "\nAll Ingredients:\n";
                                        for (const auto& ingredient : allIngredients) {
                                            cout << ingredient.getName() << ":";
                                            cout << "\n Quantity=" << ingredient.getQuantity();
                                            cout << "\n Stock=" << ingredient.getStock() << endl;
                                        }
                                    }
                                    else
                                        if (command == "RaportCl") {

                                            // Simulăm o listă de utilizatori
                                            vector<User> users = {{"Daniela Cotoi", "danielacotoi232@gmail.com"," 0751-943-940"}, {"Dragotoiu Catalin", "catalindrago@gmail.com", "0743-789-574"}, 
                                            {"Cotoi Denisa ", "denisacotoi18@gmail.com", "0763-562-970"} ,{"Dragotoiu Ruxandra", "dragotoiurux@gmail.com", "0787-911-364"}, {"Marinela Cotoi", "marinelacotoi33@gmail.com", "0767-102-397"}};

                                            // Afișăm la consolă
                                            std::cout << "Clients List:\n";
                                            for (const auto& user : users) {
                                                cout << "\n Nume: " << user.name ;
                                                cout << "\n Email: " << user.email ;
                                                cout << "\n Phone number: " << user.phoneNumber<< "\n";
                                            }

                                            // Salvăm în fișier text
                                            std::ofstream outFile("ClientsList.txt");
                                            if (outFile.is_open()) {
                                                outFile << "Clients List:\n";
                                                for (const auto& user : users) {
                                                    outFile << "\n Nume: " << user.name ;
                                                    outFile << "\n Email: " << user.email ;
                                                    outFile << "\n Phone number: " << user.phoneNumber << "\n";
                                                }
                                                outFile.close();
                                                std::cout << "\nRaportul a fost salvat in ListaUtilizatori.txt";
                                            } else {
                                                std::cerr << "\nNu am putut deschide fisierul pentru scriere.";
                                            }
                                        }
                                        else 
                                            if (command == "RaportQes") {
                                                ifstream questionFile("restaurantQuestion.txt");
                                                ifstream answerFile("restaurantAnswer.txt");

                                                // Verifică dacă fișierele au fost deschise cu succes
                                                if (!questionFile.is_open() || !answerFile.is_open()) {
                                                    cerr << "Unable to open files for reading." << std::endl;
                                                    return 1;
                                                }

                                                string question, answer;

                                                // Deschide fișierul pentru raportul final
                                                ofstream outputReportFile("raportIntrebariFrecvente.txt");
                                                if (!outputReportFile.is_open()) {
                                                    cerr << "Unable to open the output report file for writing." << std::endl;
                                                    return 1;
                                                }

                                                cout << "Raport Intrebari si Raspunsuri:\n";

                                                // Citeste si afiseaza intrebarile si raspunsurile
                                                while (std::getline(questionFile, question) && std::getline(answerFile, answer)) {
                                                    cout << "Q: " << question << std::endl;
                                                    cout << "A: " << answer << std::endl;

                                                    // Scrie intrebarea si raspunsul in fisierul de raport
                                                    outputReportFile << "Q: " << question << std::endl;
                                                    outputReportFile << "A: " << answer << std::endl;
                                                }

                                                // Inchide fisierele
                                                questionFile.close();
                                                answerFile.close();
                                                outputReportFile.close();

                                                cout << "Raport generat cu succes. Raportul final a fost salvat in fisierul raportIntrebariFrecvente.txt" << std::endl;

                                                }else
                                                    if(command == "Quit") {
                                                        // Citeste datele din fisierul binar
                                                        ifstream clientBinFileIn("client.bin", ios::binary);
                                                        Clients client;

                                                        cout << "\nClient List from Binary File:\n";
                                                        while (clientBinFileIn.peek() != EOF) {
                                                            client.readFromFile(clientBinFileIn);
                                                            for (const Meal& meal : client.getOrderP()) {
                                                                cout << "\nClient name: " << client.getName();
                                                                cout << "\nOrder name: " << meal.getName() << endl;
                                                            }
                                                        }
                                                        // Alte coduri aici

                                                    clientBinFileIn.close();  // Închide fișierul binar
                                                    cout << "\n Thank you for visiting our restaurant!";
                                                    break;
                                                    }
                                                    else{
                                                        cout << "\n Please enter a valid command";
                                                    }
        }
    }
                    





