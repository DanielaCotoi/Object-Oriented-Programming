#include <bits/stdc++.h>
#include <iostream>
#include <set>
#include <map>
#include "meal.cpp"

using namespace std;

class Menu
{
private:
    map<string, Meal> meals;

public:
    Menu() {}

    Menu(map<string, Meal> &meals)
    {
        if (!meals.empty())
            this->meals = meals;
        else
            this->meals.clear();
    }
    
    const map<string, Meal> &getMeals() const {
        return this->meals;
    }

    void setMeals(map<string, Meal> &newMeals){
            this->meals = newMeals;
    }

    Menu(const Menu &m)
    {
        if (!m.meals.empty())
            this->meals = m.meals;
        else
            this->meals.clear();
    }

    Menu &operator=(const Menu &m)
    {
        if (this != &m)
        {
            this->meals.clear();
            if (!m.meals.empty())
                this->meals = m.meals;
            else
                this->meals.clear();
        }
        return *this;
    }

    friend ostream &operator<<(ostream &out, const Menu &m)
    {
       if(!m.meals.empty() && m.meals.size() > 0){
            out<<"\nNumber of meals: "<<m.meals.size();
            out<<"\nMeals: ";
            map<string, Meal>::const_iterator im;
            for (im = m.meals.begin(); im != m.meals.end(); im++)
            {
                out << "\n Name of meals: " << im->first;
                out<< "\n Meal:" << im->second;
            }
        }
        else
        {
            out << "No meals in the menu!";
        }
        return out;
    }
    friend ofstream &operator<<(ofstream &out, const Menu &m)
    {
       if(!m.meals.empty() && m.meals.size() > 0){
            out<<"\nNumber of meals: "<<m.meals.size();
            out<<"\nMeals: ";
            map<string, Meal>::const_iterator im;
            for (im = m.meals.begin(); im != m.meals.end(); im++)
            {
                out << "\n Name of meals: " << im->first;
                out<< "\n Meal:" << im->second;
            }
        }
        else
        {
            out << "No meals in the menu!";
        }
        return out;
    }

    friend istream &operator>>(istream &in, Menu &m)
    { 
        cout<<"\n -----------------------";
        cout<<"\n Number of meals: ";
        int nrOfMeals = m.meals.size();
        in>>nrOfMeals;
        if( nrOfMeals < 0)
        {
            nrOfMeals = 0;
            m.meals.clear();
        }
        else{
            m.meals.clear();
            for(int i = 0; i < nrOfMeals; i++)
            {
                cout<<"\n Meal name:" << i + 1 << ")";
                string name;
                in >> name;
                Meal meal;
                cout<<"\n Meal: ";
                in >> meal;
                m.meals.insert(pair<string, Meal>(name, meal));

            }
        }

        return in;
    }
    friend ifstream &operator>>(ifstream &in, Menu &m)
    { 
        cout<<"\n -----------------------";
        cout<<"\n Number of meals: ";
        int nrOfMeals = m.meals.size();
        in>>nrOfMeals;
        if( nrOfMeals < 0)
        {
            nrOfMeals = 0;
            m.meals.clear();
        }
        else{
            m.meals.clear();
            for(int i = 0; i < nrOfMeals; i++)
            {
                cout<<"\n Meal name:" << i + 1 << ")";
                string name;
                in >> name;
                Meal meal;
                cout<<"\n Meal: ";
                in >> meal;
                m.meals.insert(pair<string, Meal>(name, meal));

            }
        }

        return in;
    }

   //FUNCTION FOR CALCULATING THE TOTAL PRICE OF A MEAL
    // float calculateTotalPrice()
    // {
    //     float priceT = 0;
    //     set<Meal>::iterator it;
    //     for (it = this->meals.begin(); it != this->meals.end(); it++)
    //     {
    //         priceT += it->getPrice();
    //     }
    //     return priceT;
    // }

    // void addMeal(const Meal &meal)
    // {
    //     this->meals.insert(meal);
    // }

    ~Menu() {}
};
