#include<bits/stdc++.h>

using namespace std;

class Employee
{
private:
    const int idEmployee;
    string name;
    string position;
    int salary;
    int* workedHoursPerDay;

 public:
    Employee(): idEmployee(0) {
        this->name = "";
        this->position = "";
        this->salary = 0;
        this->workedHoursPerDay = new int[5]();
    }
    const int getIdEmployee() {
        return this->idEmployee;
    }
    string getName()
    {
        return this->name;
    }
    void setName(string newName)
    {
        this->name = (newName.length() > 0) ? newName : "";
    }
    string getPosition()
    {
        return this->position;
    }
    void setPosition(string newPosition)
    {
        this->position = (newPosition.length() > 0) ? newPosition : "";
    }
    int getSalary() {
        return this->salary;
    }
    void setSalary(int newSalary) {
        this->salary = (newSalary > 0) ? newSalary : 0;
    }
    int* getworkedHoursPerDay() {
        return this->workedHoursPerDay;
    }
    void setworkedHoursPerDay(int* newworkedHoursPerDay) {
        if(newworkedHoursPerDay != nullptr) {
            for(int i = 0; i < 5; i++) {
                this->workedHoursPerDay[i] = newworkedHoursPerDay[i];
            }
        }
    }

    Employee(int idEmployee, string name, string position)
        : idEmployee(idEmployee)
    {
        this->name = (name.length() > 0) ? name : "";
        this->position = (position.length() > 0) ? position : "";
        this->salary = 0;
        this->workedHoursPerDay = new int[5]();
    }

    Employee(int idEmployee, string name, string position, int salary, int *workedHoursPerDay)
        : idEmployee(idEmployee)
    {
        this->name = (name.length() > 0) ? name : "";
        this->position = (position.length() > 0) ? position : "";
        this->salary = (salary > 0) ? salary : 0;
        this->workedHoursPerDay = new int[5];
        for(int i = 0; i < 5; i++) {
            this->workedHoursPerDay[i] = workedHoursPerDay[i];
        }
    }

    Employee(const Employee &Employee) : idEmployee(Employee.idEmployee)
    {
        this->name = (Employee.name.length() > 0) ? Employee.name : "";
        this->position = (Employee.position.length() > 0) ? Employee.position : "";
        this->salary = (Employee.salary > 0) ? Employee.salary : 0;
        this->workedHoursPerDay = new int[5];
        for (int i = 0; i < 5; i++) {
            this->workedHoursPerDay[i] = Employee.workedHoursPerDay[i];
        }
    }

    Employee& operator=(const Employee& Employee){
        if(this != &Employee){
            delete[] this->workedHoursPerDay;
            this->workedHoursPerDay = nullptr;

            this->name = (Employee.name.length() > 0) ? Employee.name : "";
            this->position = (Employee.position.length() > 0) ? Employee.position : "";
            this->salary = (Employee.salary > 0) ? Employee.salary : 0;
            this->workedHoursPerDay = new int[5];
            for (int i = 0; i < 5; i++) {
                this->workedHoursPerDay[i] = Employee.workedHoursPerDay[i];
            }
        }
        return *this;
    }
    friend ostream &operator<<(ostream &out, const Employee &Employee)
    {
        out << "\n Id: " << Employee.idEmployee << endl;
        if(Employee.name.length() > 0){
            out << "\n Name: " << Employee.name << endl;
        }
        else{
            out<<"\n Name : ------";
        }
        if(Employee.position.length() > 0){
            out << "\n Position: " << Employee.position << endl;
        }
        else{
            out<<"\n Position : ------";
        }

        out << "\n Salary: " << Employee.salary << endl;
        out << "\n Worked hours per day: ";

        if(Employee.workedHoursPerDay != nullptr){
            for(int i = 0; i < 5; i++) {
                out << Employee.workedHoursPerDay[i] << " ";
            }
        }
        else{
            out<<"\n Worked hours per day : ------";
        }
        out << endl;

        return out;
    }
    friend istream &operator>>(istream &in, Employee &Employee)
    {
        cout << "\n Name: ";
        getline(in, Employee.name);
        cout << "\n Position: ";
        getline(in, Employee.position);
        cout << "\n Salary: ";
        in >> Employee.salary;
        in.ignore(); // Ignore the newline character

        cout << "\n Worked hours per day: ";
        for(int i = 0; i < 5; i++) {
            in >> Employee.workedHoursPerDay[i];
            in.ignore(); // Ignore the newline character
        }
        return in;
    }

    ~Employee(){
        delete[] this->workedHoursPerDay;
        this->workedHoursPerDay = nullptr;   
    }
};