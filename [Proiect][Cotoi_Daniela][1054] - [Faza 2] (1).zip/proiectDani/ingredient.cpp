#include <bits/stdc++.h>

using namespace std;
// using a virtual class for the ingredients
class Iplatibil{
    public:
    virtual void writeToFile(std::ofstream& file) const = 0;
    virtual void readFromFile(std::ifstream& file) = 0;
    ~Iplatibil() {}
};

class Ingredient 
{
private:
    string name;
    int quantity;
    int stock; // Cantitatea totală de stoc

public:
    Ingredient() {
        // this->name = new char[strlen("NoName") + 1];
        // strcpy(this->name, "NoName");
        this->name = "Anonim";
        this->quantity = 0;
        this->stock = 0;
    }

    Ingredient(string name, int quantity, int stock) {
        if(name.length() > 0){
            // this->name = new char[strlen(name) + 1];
            // strcpy(this->name, name);
            this->name = name;
        }
        this->quantity = (quantity > 0) ? quantity : 0;
        this->stock = (stock > 0) ? stock : 0;
    }

    Ingredient(const Ingredient &ingredient) {
        if (ingredient.name.length() > 0){
            // this->name = new char[strlen(ingredient.name) + 1];
            // strcpy(this->name, ingredient.name);
            this->name = ingredient.name;
        }
        this->quantity = (ingredient.quantity > 0) ? ingredient.quantity : 0;
        this->stock = (ingredient.stock > 0) ? ingredient.stock : 0;
    }

    Ingredient &operator=(const Ingredient &ingredient) {
        if(this != &ingredient){

            if (ingredient.name.length() > 0){
                // this->name = new char[strlen(ingredient.name) + 1];
                // strcpy(this->name, ingredient.name);
                this->name = ingredient.name;
            }
            this->quantity = (ingredient.quantity > 0) ? ingredient.quantity : 0;
            this->stock = (ingredient.stock > 0) ? ingredient.stock : 0;
        }
        return *this;
    }

    string getName() const {
        return this->name;
    }

    void setName(string newName) {
        if(newName.length() > 0){
            // this->name = new char[strlen(newName) + 1];
            // strcpy(this->name, newName);
            this->name = newName;
        }
    }

    int getQuantity() const { return this->quantity; }

    void setQuantity(int newQuantity) {
        this->quantity = (newQuantity > 0) ? newQuantity : 0;
    }

    int getStock() const { return this->stock; }

    void setStock(int newStock) {
        this->stock = (newStock > 0) ? newStock : 0;
    }

    friend ostream &operator<<(ostream &out, const Ingredient &ingredient)
    {
        out << "Ingredient name: " << ingredient.name << endl;
        out << "Ingredient quantity: " << ingredient.quantity << endl;
        out << "Ingredient stock: " << ingredient.stock << endl;
        return out;
    }
    friend ofstream &operator<<(ofstream &out, const Ingredient &ingredient)
    {
        out << "Ingredient name: " << ingredient.name << endl;
        out << "Ingredient quantity: " << ingredient.quantity << endl;
        out << "Ingredient stock: " << ingredient.stock << endl;
        return out;
    }

    friend istream &operator>>(istream &in, Ingredient &ingredient)
    {
        cout<<"\n";
        in.ignore();
        cout << "\nIngredient name: ";
        getline(in, ingredient.name);

        cout << "\nIngredient quantity: ";
        in >> ingredient.quantity;

        cout << "\nIngredient stock: ";
        in >> ingredient.stock;

        return in;
    }
    friend ifstream &operator>>(ifstream &in, Ingredient &ingredient)
    {
        cout<<"\n";
        in.ignore();
        cout << "\nIngredient name: ";
        getline(in, ingredient.name);

        cout << "\nIngredient quantity: ";
        in >> ingredient.quantity;

        cout << "\nIngredient stock: ";
        in >> ingredient.stock;

        return in;
    }

    ~Ingredient() {
    }
    bool operator>=(int requestedQuantity){
        if (this->stock >= requestedQuantity) {
            return true;
        } else {
            cout << " " ;
            return false;
        }
    }

    Ingredient &operator-=(int requestedQuantity) 
    {
      if (this->stock >= requestedQuantity) {
            this->stock -= requestedQuantity;
            cout << "The stock are reduced succesfully!" << endl;
    } else {
            cout << " ";
    }
      return *this;
    }

    // overloading la ++(preincrementare)->cresc stocul si dupa afisez
    Ingredient& operator++()
    {
        this->stock++;
        return* this;
    }

    // overloading la --(postdecrementare)->afisez si dupa cresc stocul
    Ingredient operator++(int)
    {
        Ingredient stoc_dupa_incrementare = *this;
        this->stock++;
        return stoc_dupa_incrementare;
    }

    // overloading la --(decrementare)->cresc stocul si dupa afisez
    Ingredient& operator--()
    {
        this->stock--;
        return* this;
    }

    // overloading la --(postdecrementare)->afisez si dupa cresc stocul
    Ingredient operator--(int)
    {
        Ingredient stoc_dupa_decrementare = *this;
        this->stock--;
        return stoc_dupa_decrementare;
    }
    
    Ingredient operator+(int Addstock) { // overloading la + pt a adauga stoc
        if (Addstock > 0) {
            Ingredient result = *this;
            result.stock = this->stock + Addstock;
            return result;
        }
    }
    explicit operator int() {
		return this->stock;
	}
    bool operator!() {
		return !this->stock;
	}

    //writerofile for binary file
    virtual void writeToFile(ofstream &out) const {
        int nameSize = this->name.length();
        out.write((char*)&nameSize, sizeof(nameSize));
        out.write(this->name.c_str(), nameSize + 1);
        out.write((char*)&this->quantity, sizeof(this->quantity));
        out.write((char*)&this->stock, sizeof(this->stock));
    }
    
    
    //readfromfile for binary file
    virtual void readFromFile(ifstream &in) {
        int nameSize;
        in.read((char*)&nameSize, sizeof(nameSize));
        char *name = new char[nameSize + 1];
        in.read(name, nameSize + 1);
        this->name = name;
        delete[] name;
        in.read((char*)&this->quantity, sizeof(this->quantity));
        in.read((char*)&this->stock, sizeof(this->stock));
    }

    
};