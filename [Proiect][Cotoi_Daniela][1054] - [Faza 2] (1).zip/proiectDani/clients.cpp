#include <bits/stdc++.h>
#include "menu.cpp"

using namespace std;


class Clients 
{
private:
    const int idOrder = 0;
    string name;
    // Meal* order;
    // int nrOfOrders;
    vector<Meal> orderP;

 public:
    Clients():idOrder(0){
        this->name = "";
    }
    const int getIdOrder() {
        return this->idOrder;
    }
    string getName() {
        return this->name;
    }
    void setName(string newName) {
        this->name = (newName.length() > 0) ? newName : "";
    }
    vector<Meal>& getOrderP() {
        return this->orderP;
    }
    void setOrderP(vector<Meal>& newOrderP) {
        this->orderP = newOrderP;
    }
    Clients(int idOrder, string name, vector<Meal>& orderP )
    :idOrder(idOrder)
    {
        this->name = (name.length() > 0) ? name : "";
        this->orderP = orderP;
    }
    Clients(const Clients& client): idOrder(client.idOrder)
    {
        this->name = (client.name.length() > 0) ? client.name : "";
        this->orderP = client.orderP;
    }

    Clients& operator=(const Clients& client){
        if(this != &client){

            this->name = (client.name.length() > 0) ? client.name : "";
            this->orderP = client.orderP;
        }

        return *this;
    }

    friend ostream &operator<<(ostream &out, const Clients &client)
    {
         out << "\n Id order: " << client.idOrder ;
         out << "\nClient name: " << client.name << endl;

         out<<"\n Number of meals: " << client.orderP.size() << endl;
         out << "\n Order: ";
         for(auto i = client.orderP.begin(); i != client.orderP.end(); i++){
             out << *i << endl;
        }  
        return out;
    }
    friend ofstream &operator<<(ofstream &out, const Clients &client)
    {
         out << "\n Id order: " << client.idOrder ;
         out << "\nClient name: " << client.name << endl;

         out<<"\n Number of meals: " << client.orderP.size() << endl;
         out << "\n Order: ";
         for(auto i = client.orderP.begin(); i != client.orderP.end(); i++){
             out << *i << endl;
        }  
        return out;
    }

    friend istream &operator>>(istream &in, Clients &client)
    {
        cin.ignore();
        cout << "\n Name: ";
        getline(in, client.name);

        client.orderP.clear();
        int nrOfOrders;
        cout << "\n Number of meals: ";
        in >> nrOfOrders;

        cout<<"\n Order: ";
        for(int i = 0; i < nrOfOrders; i++){
            Meal meal;
            in >> meal;
            client.orderP.push_back(meal);
        }
        return in;
    }
    friend ifstream &operator>>(ifstream &in, Clients &client)
    {
        cin.ignore();
        cout << "\n Name: ";
        getline(in, client.name);

        client.orderP.clear();
        int nrOfOrders;
        cout << "\n Number of meals: ";
        in >> nrOfOrders;

        cout<<"\n Order: ";
        for(int i = 0; i < nrOfOrders; i++){
            Meal meal;
            in >> meal;
            client.orderP.push_back(meal);
        }
        return in;
    }
    bool operator<(const Clients& client) const {
        if (this->idOrder < client.idOrder) {
             return true;
        } else if (this->idOrder == client.idOrder) {
            return this->name < client.name;
        }
        return false;
    }

    void writeToFile(ofstream& out) const {
        int nameSize = this->name.size();
        out.write((char*)&nameSize, sizeof(int));
        out.write(this->name.c_str(), nameSize);

        int orderSize = this->orderP.size();
        out.write((char*)&orderSize, sizeof(int));
        for (const Meal& meal : this->orderP) {
            meal.writeToFile(out);
        }
        // Adaugă un separator între obiectele Clients
        out.write((char*)&orderSize, sizeof(int));
    }

    void readFromFile(ifstream& in) {
        int nameSize;
        in.read((char*)&nameSize, sizeof(int));
        char* name = new char[nameSize + 1];
        in.read(name, nameSize);
        name[nameSize] = '\0';
        this->name = name;
        delete[] name;
        
        this->orderP.clear();
        int orderSize;
        in.read((char*)&orderSize, sizeof(int));
        for (int i = 0; i < orderSize; ++i) {
            Meal meal;
            meal.readFromFile(in);
            this->orderP.push_back(meal);
        }
        // Sari peste separator
        in.read((char*)&orderSize, sizeof(int));
    }

    ~Clients() {}
};


    
