#include <bits/stdc++.h>
#include<list>
#include "ingredient.cpp"

using namespace std;

class Meal 
{
private:
    string name;
    string description;
    float price;
    int quantity;
    list<Ingredient> ingredients;

public:
    Meal() {
        this->name = "";
        this->description = "";
        this->price = 0;
        this->quantity = 0;
    }

    string getName() const { return this->name; }

    void setName(string newName) {
        name = (newName.length() > 0) ? newName : "";
    }

    string getDescription() { return this->description; }

    void setDescription(string newDescription) {
        description = (newDescription.length() > 0) ? newDescription : "";
    }

    float getPrice() const { return this->price; }

    void setPrice(float newPrice) {
        price = (newPrice > 0) ? newPrice : 0;
    }

    int getQuantity() { return this->quantity; }

    void setQuantity(int newQuantity) {
        quantity = (newQuantity > 0) ? newQuantity : 0;

    }

    list<Ingredient>& getIngredients() { return this->ingredients; }

    void setIngredients(list<Ingredient>& newIngredients) {
        if(!newIngredients.empty())
            this->ingredients = newIngredients;
        else
            this->ingredients.clear();
    }
    

    Meal(string name, string description, float price, int quantity, list<Ingredient>& ingredients) 
    {
        this->name = name.length() > 0 ? name : "";
        this->description = description.length() > 0 ? description : "";
        this->price = (price > 0) ? price : 0;
        this->quantity = (quantity > 0) ? quantity : 0;

        if(!ingredients.empty())
            this->ingredients = ingredients;
        else
            this->ingredients.clear();
    }

    Meal(const Meal& meal) {
        this->name = (meal.name.length() > 0 && meal.name != " ")? meal.name : " ";
        this->description = (meal.description.length () > 0 && meal.description != " ") ? meal.description : " ";
        this->price = (meal.price > 0) ? meal.price : 0;
        this->quantity = (meal.quantity > 0)? meal.quantity : 0;
        if(!meal.ingredients.empty())
            this->ingredients = meal.ingredients;
        else
            this->ingredients.clear();
    }

    Meal &operator=(const Meal &meal) {
        if (this != &meal) {
            this->name = (meal.name.length() > 0 && meal.name != " ") ? meal.name : " ";
            this->description = (meal.description.length() > 0 && meal.description != " ") ? meal.description : " ";
            this->price = (meal.price > 0) ? meal.price : 0;
            this->quantity = (meal.quantity > 0) ? meal.quantity : 0;
            if (!meal.ingredients.empty())
                this->ingredients = meal.ingredients;
            else
                this->ingredients.clear();
        }
        return *this;
    }
    friend ostream &operator<<(ostream &out, const Meal &meal)
    {
        out << "Meal name:" << meal.name<< endl;
        out << "Meal description: " << meal.description << endl;
        out << "Meal price: " << meal.price << endl;
        out << "Meal quantity: " << meal.quantity << endl;
        out << "Number of ingredients: " << meal.ingredients.size() << endl;
        out << "Ingredients: " << endl;
        for (auto i = meal.ingredients.begin(); i != meal.ingredients.end(); i++) {
            out << *i << endl;
        }
        return out;
    }
    friend ofstream &operator<<(ofstream &out, const Meal &meal)
    {
        out << "Meal name:" << meal.name<< endl;
        out << "Meal description: " << meal.description << endl;
        out << "Meal price: " << meal.price << endl;
        out << "Meal quantity: " << meal.quantity << endl;
        out << "Number of ingredients: " << meal.ingredients.size() << endl;
        out << "Ingredients: " << endl;
        for (auto i = meal.ingredients.begin(); i != meal.ingredients.end(); i++) {
            out << *i << endl;
        }
        return out;
    }
    

    friend istream &operator>>(istream &in, Meal &meal) {
        cout << "Meal name: ";
        getline(in, meal.name);

        cout << "Meal description: ";
        getline(in, meal.description);

        cout << "Meal price: ";
        in >> meal.price;

        cout << "Meal quantity: ";
        in >> meal.quantity;

        meal.ingredients.clear();

        int numIngredients;
        cout << "\nNumber of Ingredients: ";
        in >> numIngredients;

        cout << "\nIngredients: ";
        for (int i = 0; i < numIngredients; i++) {
            Ingredient ingredient;
            in >> ingredient;
            meal.ingredients.push_back(ingredient);
        }

        return in;
    }
    friend ifstream &operator>>(ifstream &in, Meal &meal) {
        cout << "Meal name: ";
        getline(in, meal.name);

        cout << "Meal description: ";
        getline(in, meal.description);

        cout << "Meal price: ";
        in >> meal.price;

        cout << "Meal quantity: ";
        in >> meal.quantity;

        meal.ingredients.clear();

        int numIngredients;
        cout << "\nNumber of Ingredients: ";
        in >> numIngredients;

        cout << "\nIngredients: ";
        for (int i = 0; i < numIngredients; i++) {
            Ingredient ingredient;
            in >> ingredient;
            meal.ingredients.push_back(ingredient);
        }

        return in;
    }
    //OVERLOADING AT == TO CHECK IF TWO MEALS ARE THE SAME
    bool operator==(const Meal &meal) {
        if (this->name == meal.name && this->description == meal.description && this->price == meal.price && this->quantity == meal.quantity) {
            return true;
        }
        else {
            return false;
        }
    }

    //  //writing in a binary file 
    //  void writeToFile(ofstream& out) {
    //     int nameSize = this->name.size();
    //     out.write((char*)&nameSize, sizeof(int));
    //     out.write(this->name.c_str(), nameSize);

    //     int descriptionSize = this->description.size();
    //     out.write((char*)&descriptionSize, sizeof(int));
    //     out.write(this->description.c_str(), descriptionSize);

    //     out.write((char*)&this->price, sizeof(float));
    //     out.write((char*)&this->quantity, sizeof(int));

    //     int ingredientsSize = this->ingredients.size();
    //     out.write((char*)&ingredientsSize, sizeof(int));

    //     for (auto i = this->ingredients.begin(); i != this->ingredients.end(); i++) {
    //         i->writeToFile(out);
    //     }
    //  }

    //  // reading from a binary file
    //     void readFromFile(ifstream& in) {
    //         int nameSize;
    //         in.read((char*)&nameSize, sizeof(int));
    //         char* name = new char[nameSize + 1];
    //         in.read(name, nameSize);
    //         name[nameSize] = '\0';
    //         this->name = name;
    //         delete[] name;
    
    //         int descriptionSize;
    //         in.read((char*)&descriptionSize, sizeof(int));
    //         char* description = new char[descriptionSize + 1];
    //         in.read(description, descriptionSize);
    //         description[descriptionSize] = '\0';
    //         this->description = description;
    //         delete[] description;
    
    //         in.read((char*)&this->price, sizeof(float));
    //         in.read((char*)&this->quantity, sizeof(int));
    
    //         int ingredientsSize;
    //         in.read((char*)&ingredientsSize, sizeof(int));
    
    //         for (int i = 0; i < ingredientsSize; i++) {
    //             Ingredient ingredient;
    //             ingredient.readFromFile(in);
    //             this->ingredients.push_back(ingredient);
    //         }
    //     }
     
    // Funcție pentru citire
    bool readFromFile(ifstream &in) {
        int nameSize;
        in.read((char*)&nameSize, sizeof(int));
        if (!in) return false;  // Dacă nu se poate citi, întoarce false

        char* name = new char[nameSize + 1];
        in.read(name, nameSize);
        name[nameSize] = '\0';
        this->name = name;
        delete[] name;

        int descriptionSize;
        in.read((char*)&descriptionSize, sizeof(int));
        if (!in) return false;

        char* description = new char[descriptionSize + 1];
        in.read(description, descriptionSize);
        description[descriptionSize] = '\0';
        this->description = description;
        delete[] description;

        in.read((char*)&this->price, sizeof(float));
        in.read((char*)&this->quantity, sizeof(int));

        int ingredientsSize;
        in.read((char*)&ingredientsSize, sizeof(int));
        if (!in) return false;

        this->ingredients.clear();  // Golește lista de ingrediente

        for (int i = 0; i < ingredientsSize; ++i) {
            Ingredient ingredient;
            ingredient.readFromFile(in);
            this->ingredients.push_back(ingredient);
        }

        return true;  // Toate citirile au fost cu succes, întoarce true
    }

    // Funcție pentru scriere în fișier binar
    void writeToFile(ofstream &out) const {
        int nameSize = this->name.size();
        out.write((char*)&nameSize, sizeof(int));
        out.write(this->name.c_str(), nameSize);

        int descriptionSize = this->description.size();
        out.write((char*)&descriptionSize, sizeof(int));
        out.write(this->description.c_str(), descriptionSize);

        out.write((char*)&this->price, sizeof(float));
        out.write((char*)&this->quantity, sizeof(int));

        int ingredientsSize = this->ingredients.size();
        out.write((char*)&ingredientsSize, sizeof(int));

        for (const Ingredient &ingredient : this->ingredients) {
            ingredient.writeToFile(out);
        }
    }




     // Destructor
    ~Meal() {}

};


   

    
    



