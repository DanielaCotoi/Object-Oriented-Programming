#include <bits/stdc++.h>
#include "ingredient.cpp"

using namespace std;

class Meal 
{
private:
    string name;
    string description;
    float price;
    int quantity;
    Ingredient *ingredients;
    int nrOfIngredients;

public:
    Meal() {
        this->name = "";
        this->description = "";
        this->price = 0;
        this->quantity = 0;
        this->ingredients = nullptr;
        this->nrOfIngredients = 0;
    }

    string getName() { return this->name; }

    void setName(string newName) {
        name = (newName.length() > 0) ? newName : "";
    }

    string getDescription() { return this->description; }

    void setDescription(string newDescription) {
        description = (newDescription.length() > 0) ? newDescription : "";
    }

    int getPrice() { return this->price; }

    void setPrice(float newPrice) {
        price = (newPrice > 0) ? newPrice : 0;
    }

    int getQuantity() { return this->quantity; }

    void setQuantity(int newQuantity) {
        quantity = (newQuantity > 0) ? newQuantity : 0;

    }

    Ingredient *getIngredients() { return this->ingredients; }

    void setIngredients(Ingredient *newIngredients, int newNrOfIngredients) {
        if (newIngredients != nullptr && newNrOfIngredients > 0) {
            this->nrOfIngredients = newNrOfIngredients;
            delete[] this->ingredients;
            this->ingredients = new Ingredient[this->nrOfIngredients];
            for (int i = 0; i < this->nrOfIngredients; i++)
                this->ingredients[i] = newIngredients[i];
        }
    }
    
    int getNrOfIngredients() { return this->nrOfIngredients; }
    
    void setNrOfIngredients(int newNrOfIngredients) {
        this->nrOfIngredients = (newNrOfIngredients > 0) ? newNrOfIngredients : 0;
    }

    Meal(string name, string description, float price, int quantity,
             Ingredient *ingredients, int nrOfIngredients) 
    {
        this->name = name.length() > 0 ? name : "";
        this->description = description.length() > 0 ? description : "";
        this->price = (price > 0) ? price : 0;
        this->quantity = (quantity > 0) ? quantity : 0;

        if (ingredients != nullptr && nrOfIngredients > 0) {
            this->nrOfIngredients = nrOfIngredients;
            this->ingredients = new Ingredient[nrOfIngredients];

            for (int i = 0; i < nrOfIngredients; i++)
                this->ingredients[i] = ingredients[i];
        } else {
            this->ingredients = nullptr;
            this->nrOfIngredients = 0;
        }
    }

    Meal(Meal &meal) {
        this->name = (meal.name.length() > 0 && meal.name != " ")? meal.name : " ";
        this->description = (meal.description.length () > 0 && meal.description != " ") ? meal.description : " ";
        this->price = (meal.price > 0) ? meal.price : 0;
        this->quantity = (meal.quantity > 0)? meal.quantity : 0;
        if (meal.ingredients != nullptr && meal.nrOfIngredients > 0) {
            this->nrOfIngredients = meal.nrOfIngredients;
            this->ingredients = new Ingredient[this->nrOfIngredients];
            for (int i = 0; i < this->nrOfIngredients; i++)
                this->ingredients[i] = meal.ingredients[i];
        } else {
            this->ingredients = nullptr;
            this->nrOfIngredients = 0;
        }
    }

    Meal &operator=(const Meal &meal) {
        if (this != &meal) {
            delete[] this->ingredients;
            this->ingredients = nullptr;
            this->name = (meal.name.length() > 0 && meal.name != " ")? meal.name : " ";
            this->description = (meal.description.length () > 0 && meal.description != " ") ? meal.description : " ";
            this->price = (meal.price > 0) ? meal.price : 0;
            this->quantity = (meal.quantity > 0)? meal.quantity : 0;
            if (meal.ingredients != nullptr && meal.nrOfIngredients > 0) {
                this->nrOfIngredients = meal.nrOfIngredients;
                this->ingredients = new Ingredient[this->nrOfIngredients];
                for (int i = 0; i < this->nrOfIngredients; i++)
                    this->ingredients[i] = meal.ingredients[i];
            } else {
                this->ingredients = nullptr;
                this->nrOfIngredients = 0;
            }
        }
        return *this;
    }
    friend ostream &operator<<(ostream &out, const Meal &meal)
    {
        out << "Meal name:" << meal.name<< endl;
        out << "Meal description: " << meal.description << endl;
        out << "Meal price: " << meal.price << endl;
        out << "Meal quantity: " << meal.quantity << endl;
        out << "Number of ingredients:" << meal.nrOfIngredients << endl;
        out << "Ingredients: " << endl;
        for (int i = 0; i < meal.nrOfIngredients; i++) {
            out << i + 1 << ").  " << endl;
            out << meal.ingredients[i];
        }
        return out;
    }
    friend istream &operator>>(istream &in, Meal &meal)
    {
        cout << "Meal name: ";
        getline(in, meal.name);

        cout << "Meal description: ";
        getline(in, meal.description);

        cout << "Meal price: ";
        in >> meal.price;

        cout << "Meal quantity: ";
        in >> meal.quantity;

        cout << "Number of ingredients: ";
        in >> meal.nrOfIngredients;
        
        cout << "Ingredients: " << endl;
        for (int i = 0; i < meal.nrOfIngredients; i++) {
            cout << i + 1 << ").  " << endl;
            in >> meal.ingredients[i];
        }
        return in;
    }
    //OVERLOADING AT == TO CHECK IF TWO MEALS ARE THE SAME
    bool operator==(const Meal &meal) {
        if (this->name == meal.name && this->description == meal.description && this->price == meal.price && this->quantity == meal.quantity && this->nrOfIngredients == meal.nrOfIngredients) {
            return true;
        }
        else {
            return false;
        }
    }
    
    //overloading at [] to return the stock of an ingredient
    int operator[](int index) {
        if (index >= 0 && index < 100) {
            return this->ingredients[index].getStock();
        }
        else {
            throw exception();
        }
    }
    // Destructor
    ~Meal() {
        delete[] this->ingredients;
        this->ingredients = nullptr;
    }
   

    
    


};
