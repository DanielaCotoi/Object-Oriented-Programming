#include <bits/stdc++.h>
#include<iostream>
#include "meal.cpp"

using namespace std;

class Menu
{
    private:
        Meal* meals;
        int numberOfMeals;


    public:
    Menu()
    {
        this->meals = nullptr;
        this->numberOfMeals = 0;
    }
    Menu(Meal* meals, int numberOfMeals){

        if (meals != nullptr && numberOfMeals > 0)
        {
            this->numberOfMeals = numberOfMeals;
            this->meals = new Meal[this->numberOfMeals];
            for (int i = 0; i < this->numberOfMeals; i++)
                this->meals[i] = meals[i];
        }
        else
        {
            this->meals = nullptr;
            this->numberOfMeals = 0;
        }
    }
    Meal *getmeals()
    {
        return this->meals;
    }

    void setmeals(Meal *newMeals, int newNumberOfMeals)
    {
        if (newMeals != nullptr && newNumberOfMeals > 0)
        {
            this->numberOfMeals = newNumberOfMeals;
            delete[] this->meals; // Eliberăm memoria veche înainte de a seta una nouă
            this->meals = new Meal[this->numberOfMeals];
            for (int i = 0; i < this->numberOfMeals; i++)
                this->meals[i] = newMeals[i];
        }
    }

    int getNumberOfMeals(){
        return this->numberOfMeals;
    }

    Menu(const Menu &m)
    {
        if (m.meals != nullptr && m.numberOfMeals > 0)
        {
            this->numberOfMeals = m.numberOfMeals;
            this->meals = new Meal[this->numberOfMeals];
            for (int i = 0; i < this->numberOfMeals; i++)
                this->meals[i] = m.meals[i];
        }
        else
        {
            this->meals = nullptr;
            this->numberOfMeals = 0;
        }
    }
    Menu& operator=(const Menu &m)
    {
        if (this != &m)
        {
            delete[] meals;
            this->meals = nullptr;
            if (m.meals != nullptr && m.numberOfMeals > 0)
            {
                this->numberOfMeals = m.numberOfMeals;
                this->meals = new Meal[this->numberOfMeals];
                for (int i = 0; i < this->numberOfMeals; i++)
                    this->meals[i] = m.meals[i];
            }
            else
            {
                this->meals = nullptr;
                this->numberOfMeals = 0;
            }
        }
        return *this;
    }
    friend ostream &operator<<(ostream &out, const Menu &m)
    {
        out << "\n Number of meals: " << m.numberOfMeals << endl;
        out<<"\n Meals:";
        for(int i = 0; i < m.numberOfMeals; i++){
            out << " " << m.meals[i];
            out << endl;
        }
        return out;
    }
    friend istream &operator>>(istream &in, Menu &m)
    {
        cout << "\n Number of meals: ";
        in >> m.numberOfMeals;
        in.ignore(); // Ignore the newline character

        cout << "\n Meals:";
        for (int i = 0; i < m.numberOfMeals; i++)
        {
            in >> m.meals[i];
            in.ignore(); // Ignore the newline character after each meal
        }
        return in;
    }
    //FUNCTION FOR CALCULATING THE TOTAL PRICE OF A MEAL
    double calculateTotalPrice() {
        double priceT = 0;
        for (int i = 0; i < this->numberOfMeals; i++) {
            priceT += this->meals[i].getPrice();
        }
        return priceT;
    }
    void addMeal(Meal &meal) {
        Meal *aux = new Meal[this->numberOfMeals + 1];
        for (int i = 0; i < this->numberOfMeals; i++) {
            aux[i] = this->meals[i];
        }
        aux[this->numberOfMeals] = meal;
        this->numberOfMeals++;
        delete[] this->meals;
        this->meals = aux;
    }


    ~Menu()
    {
        delete[] meals;
        this->meals = nullptr;
    }
};