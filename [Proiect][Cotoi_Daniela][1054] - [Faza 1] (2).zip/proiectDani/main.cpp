#include <bits/stdc++.h>
#include "restaurant.cpp"

using namespace std;

int main()
{   
    int *ore1 = new int[5];
    ore1[0] = 8;
    ore1[1] = 12;
    ore1[2] = 4;
    ore1[3] = 8;
    ore1[4] = 8;

    int *ore2 = new int[5];
    ore2[0] = 8;
    ore2[1] = 6;
    ore2[2] = 8;
    ore2[3] = 8;
    ore2[4] = 6;

    Employee John( 1, "John", "Chef", 40, ore1);
    Employee Maria( 2, "Maria", "Waiter", 36, ore2 );
    Employee Anne( 3, "Anne" , "Cook", 40, ore1);
    Employee emp[] = {John, Maria, Anne};

    Ingredient pizzaIngredients[] = {Ingredient("Flour",25, 100), Ingredient("Tomato Sauce", 25, 100), Ingredient("Cheese", 10, 100)};
    Meal pizza("Pizza", "Delicious pizza with tomato sauce and chesse", 30, 1, pizzaIngredients, 3);

    Ingredient burgerIngredients[] = {Ingredient("Beef Patty", 30, 100), Ingredient("Bun", 10, 100), Ingredient("Lettuce", 10, 100), Ingredient("Tomato", 10, 100), Ingredient("Potato", 20, 100)};
    Meal burger("Burger", "Classic beef burger with lettuce and tomato", 40, 1, burgerIngredients, 5);

    Ingredient cakeIngredients[] = {Ingredient("Flour", 30, 100), Ingredient("Sugar", 15, 100), Ingredient("Eggs", 4, 100), Ingredient("Chocolate", 100, 100)};
    Meal cake("Cake", "Sweet chocolate cake", 20, 1, cakeIngredients, 4);

    Ingredient lasagnaIngredients[] = {Ingredient("Pasta", 30, 100), Ingredient("Tomato Sauce", 10, 100), Ingredient("Ground Beef", 30, 100), Ingredient("Cheese", 10, 100)};
    Meal lasagna("Lasagna", "Traditional Italian lasagna with ground beef", 45, 1, lasagnaIngredients, 4);

    Meal menuMeals[] = {pizza, burger, cake, lasagna};
    Menu restaurantMenu(menuMeals, 4);

    cout<<"\n Welcome to my restaurant";
    while(true)
    {
        cout <<"\n Write command to see the list of commands: ";
		string command;
		cin >> command;

		if (command == "command")
		{
			cout << "\n ------ What are you interested in ?-----";
			cout << "\n 1).Menu (our meals)";
			cout << "\n 2).Add_order ";
            cout << "\n 3).Delete_order";
			cout << "\n 4).Details_about_restaurant(name,employees)";
			cout << "\n 5).Quit";
		}
        else
			if (command == "Add_order")
			{
                 // read the client name
                 string clientName;
                 cout << "\n Please enter your full name: ";
                 cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                 getline(cin, clientName);

                 Clients client1(1, "Daniela Cotoi", &pizza, restaurantMenu, 1);
                 Clients client2(2, "Andrei Catalin", &burger, restaurantMenu, 1);
                 Clients client3(3, "Maria Ioana", &cake, restaurantMenu, 1);
                 Clients client4(4, "Denisa Elena", &lasagna, restaurantMenu, 1);
                 Clients client[] = {client1, client2, client3, client4};

                 if(clientName == "Daniela Cotoi")
                    cout << "\n You ," << clientName << ", have rezervation!";
                 else
                    if(clientName == "Andrei Catalin")
                        cout << "\n You, " << clientName << " , have rezervation !";
                    else
                        if(clientName == "Maria Ioana")
                            cout << "\n You ," << clientName << " ,have rezervation!";
                        else
                            if(clientName == "Denisa Elena")
                                cout << "\n You ," << clientName << ", have rezervation!";
                            else {
                                cout << "\n Sorry, "<< clientName << " ,you dont't have rezervation!";
                                break;
                            }

                 cout << "\n What would you like to order?";
                 string orderName;
                 cout <<"\n ";
                 cin >> orderName;

                 while (orderName != "Pizza" && orderName != "Burger" && orderName != "Cake" && orderName != "Lasagna")
                {
                    cout << "\n Sorry, we don't have this meal in our menu";
                    cout << " Would you like to order something else? (Y/N)";
                    char answer;
                    cin >> answer;

                    // Clear the input buffer
                    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

                    if (answer == 'Y' || answer == 'y') {
                 // Continue the inner loop
                        cout << "\n What would you like to order?";
                        cout << "\n ";
                        cin >> orderName;
                    } 
                    else
                         if (answer == 'n' || answer == 'N') {
                            // Exit the inner loop and return to reading the name
                            break;
                            } else {
                            cout << "\n Please enter a valid answer";
                            // Don't break here to allow the user to retry entering the order
                            }
                 }

                 // If you reach here, check if the order is valid and display the success message
                 if (orderName == "Pizza" || orderName == "Burger" || orderName == "Cake" || orderName == "Lasagna") 
                 {
                    //i want to reduce the stock of the ingredients
                    int requestedQuantity;
                    cout << "\n Please enter the quantity you want: ";
                    cin >> requestedQuantity;
                    if( requestedQuantity < 0)
                        cout << "\n Please enter a valid quantity";
                    else
                        if (requestedQuantity > 0) 
                        {
                            if (orderName == "Pizza") 
                            {
                                 Ingredient& ingredient1 = pizzaIngredients[0];
                                 Ingredient& ingredient2 = pizzaIngredients[1];
                                 Ingredient& ingredient3 = pizzaIngredients[2];

                                if (ingredient1 >= requestedQuantity && ingredient2 >= requestedQuantity && ingredient3 >= requestedQuantity)
                                {
                                     ingredient1 -= requestedQuantity;
                                     cout<<"\n Stock of " << ingredient1.getName() << " is :" << ingredient1.getStock() << endl;
                                     ingredient2 -= requestedQuantity;
                                     cout<<"\n Stock of " << ingredient2.getName() << " is: " << ingredient2.getStock() << endl;
                                     ingredient3 -= requestedQuantity;
                                     cout<<"\n Stock of " << ingredient3.getName() << " is :" << ingredient3.getStock() << endl;
                                     cout << "\n Your order has been placed successfully!";
                                } 
                                else
                                {
                                    cout << "\n Sorry, we don't have enough stock for your order";
                                    cout << "\n Let me see if we can add more stock";

                                    cout << "\n The stock of the pizza is: ";
                                    cout << "  " << pizzaIngredients[0].getName() << ": " << pizzaIngredients[0].getStock() << endl;
                                    cout << "   " <<pizzaIngredients[1].getName() << ": " << pizzaIngredients[1].getStock() << endl;
                                    cout << "   " << pizzaIngredients[2].getName() << ": " <<pizzaIngredients[2].getStock() << endl;

                                    int addStock[3];
                                    for (int i = 0; i < 3; i++) {
                                        cout << "\n Please enter the quantity you want to add for " << pizzaIngredients[i].getName() << ": ";
                                        cin >> addStock[i];
                                        }

                                    ingredient1 = ingredient1 + addStock[0];
                                    ingredient2 = ingredient2 + addStock[1];
                                    ingredient3 = ingredient3 + addStock[2];

                                    cout << "\n The new stock is: ";
                                    cout << "  " << pizzaIngredients[0].getName() << ": " << pizzaIngredients[0].getStock() << endl;
                                    cout << "   " <<pizzaIngredients[1].getName() << ": " << pizzaIngredients[1].getStock() << endl;
                                    cout << "   " <<pizzaIngredients[2].getName() << ": " << pizzaIngredients[2].getStock() << endl;

                                    cout << "\n Your order has been placed successfully!";
                                    }
                            
                                
                            }
                            else
                                if(orderName == "Burger")
                                {
                                    Ingredient& ingredient1 = burgerIngredients[0];
                                    Ingredient& ingredient2 = burgerIngredients[1];
                                    Ingredient& ingredient3 = burgerIngredients[2];
                                    Ingredient& ingredient4 = burgerIngredients[3];
                                    Ingredient& ingredient5 = burgerIngredients[4];
                                    if(ingredient1 >= requestedQuantity && ingredient2 >= requestedQuantity && ingredient3 >= requestedQuantity && ingredient4 >= requestedQuantity && ingredient5 >= requestedQuantity)
                                    {
                                        ingredient1 -= requestedQuantity;
                                        cout<<"\n Stock of " << ingredient1.getName() << " is :" << ingredient1.getStock() << endl;
                                        ingredient2 -= requestedQuantity;
                                        cout<<"\n Stock of " << ingredient2.getName() << " is: " << ingredient2.getStock() << endl;
                                        ingredient3 -= requestedQuantity;
                                        cout<<"\n Stock of " << ingredient3.getName() << " is :" << ingredient3.getStock() << endl;
                                        ingredient4 -= requestedQuantity;
                                        cout<<"\n Stock of " << ingredient4.getName() << " is :" << ingredient4.getStock() << endl;
                                        ingredient5 -= requestedQuantity;
                                        cout<<"\n Stock of " << ingredient5.getName() << " is :" << ingredient5.getStock() << endl;
                                        cout << "\n Your order has been placed successfully!";
                                    }
                                    else
                                    {
                                       cout << "Not enought stock to satisfy the demand for" << requestedQuantity << " unity." << endl;
                                       cout <<"\n Let me see if we can add more stock";

                                        cout << "\n The stock of the burger is: ";
                                        cout << "  " << burgerIngredients[0].getName() << ": " << burgerIngredients[0].getStock() << endl;
                                        cout << "   " <<burgerIngredients[1].getName() << ": " << burgerIngredients[1].getStock() << endl;
                                        cout << "   " << burgerIngredients[2].getName() << ": " <<burgerIngredients[2].getStock() << endl;
                                        cout << "   " << burgerIngredients[3].getName() << ": " <<burgerIngredients[3].getStock() << endl;
                                        cout << "   " << burgerIngredients[4].getName() << ": " <<burgerIngredients[4].getStock() << endl;

                                        int addStock[5];
                                        for (int i = 0; i < 5; i++) {
                                            cout << "\n Please enter the quantity you want to add for " << burgerIngredients[i].getName() << ": ";
                                            cin >> addStock[i];
                                        }

                                        ingredient1 = ingredient1 + addStock[0];
                                        ingredient2 = ingredient2 + addStock[1];
                                        ingredient3 = ingredient3 + addStock[2];
                                        ingredient4 = ingredient4 + addStock[3];
                                        ingredient5 = ingredient5 + addStock[4];

                                        cout << "\n The new stock is: ";
                                        cout << "  " << burgerIngredients[0].getName() << ": " << burgerIngredients[0].getStock() << endl;
                                        cout << "   " <<burgerIngredients[1].getName() << ": " << burgerIngredients[1].getStock() << endl;
                                        cout << "   " <<burgerIngredients[2].getName() << ": " << burgerIngredients[2].getStock() << endl;
                                        cout << "   " <<burgerIngredients[3].getName() << ": " << burgerIngredients[3].getStock() << endl;
                                        cout << "   " <<burgerIngredients[4].getName() << ": " << burgerIngredients[4].getStock() << endl;

                                        cout << "\n Your order has been placed successfully!";
                                    }
                                }
                                else
                                    if(orderName == "Cake")
                                    {
                                        Ingredient& ingredient1 = cakeIngredients[0];
                                        Ingredient& ingredient2 = cakeIngredients[1];
                                        Ingredient& ingredient3 = cakeIngredients[2];
                                        Ingredient& ingredient4 = cakeIngredients[3];

                                        if(ingredient1 >= requestedQuantity && ingredient2 >= requestedQuantity && ingredient3 >= requestedQuantity && ingredient4 >= requestedQuantity)
                                        {
                                            ingredient1 -= requestedQuantity;
                                            cout << "\n Stock of " << ingredient1.getName() << " is :" << ingredient1.getStock() << endl;
                                            ingredient2 -= requestedQuantity;
                                            cout << "\n Stock of " << ingredient2.getName() << " is: " << ingredient2.getStock() << endl;
                                            ingredient3 -= requestedQuantity;
                                            cout << "\n Stock of " << ingredient3.getName() << " is :" << ingredient3.getStock() << endl;
                                            ingredient4 -= requestedQuantity;
                                            cout << "\n Stock of " << ingredient4.getName() << " is :" << ingredient4.getStock() << endl;
                                            cout << "\n Your order has been placed successfully!";
                                        }
                                        else
                                        {
                                           cout << "Not enought stock to satisfy the demand for" << requestedQuantity << " unity." << endl;
                                           cout << "Let me see if we can add more stock";
                                           
                                           cout << "\n The stock of the cake is: ";
                                           cout << "  " << cakeIngredients[0].getName() << ": " << cakeIngredients[0].getStock() << endl;
                                           cout << "   " <<cakeIngredients[1].getName() << ": " << cakeIngredients[1].getStock() << endl;
                                           cout << "   " << cakeIngredients[2].getName() << ": " <<cakeIngredients[2].getStock() << endl;
                                           cout << "   " << cakeIngredients[3].getName() << ": " <<cakeIngredients[3].getStock() << endl;

                                           int addStock[4];
                                            for (int i = 0; i < 4; i++) {
                                                  cout << "\n Please enter the quantity you want to add for " << cakeIngredients[i].getName() << ": ";
                                                  cin >> addStock[i];
                                            }
                                            ingredient1 = ingredient1 + addStock[0];
                                            ingredient2 = ingredient2 + addStock[1];
                                            ingredient3 = ingredient3 + addStock[2];
                                            ingredient4 = ingredient4 + addStock[3];

                                            cout << "\n The new stock is: ";
                                            cout << "  " << cakeIngredients[0].getName() << ": " << cakeIngredients[0].getStock() << endl;
                                            cout << "   " <<cakeIngredients[1].getName() << ": " << cakeIngredients[1].getStock() << endl;
                                            cout << "   " <<cakeIngredients[2].getName() << ": " << cakeIngredients[2].getStock() << endl;
                                            cout << "   " <<cakeIngredients[3].getName() << ": " << cakeIngredients[3].getStock() << endl;

                                            cout<<"\n Your order has been placed successfully!";
                                        }
                                    }
                                    else
                                        if(orderName == "Lasagna")
                                        {
                                            Ingredient& ingredient1 = lasagnaIngredients[0];
                                            Ingredient& ingredient2 = lasagnaIngredients[1];
                                            Ingredient& ingredient3 = lasagnaIngredients[2];
                                            Ingredient& ingredient4 = lasagnaIngredients[3];

                                            if(ingredient1 >= requestedQuantity && ingredient2 >= requestedQuantity && ingredient3 >= requestedQuantity && ingredient4 >= requestedQuantity)
                                            {
                                                ingredient1 -= requestedQuantity;
                                                cout <<"\n Stock of " << ingredient1.getName() << " is :" << ingredient1.getStock() << endl;
                                                ingredient2 -= requestedQuantity;
                                                cout <<"\n Stock of " << ingredient2.getName() << " is: " << ingredient2.getStock() << endl;
                                                ingredient3 -= requestedQuantity;
                                                cout <<"\n Stock of " << ingredient3.getName() << " is :" << ingredient3.getStock() << endl;
                                                ingredient4 -= requestedQuantity;
                                                cout <<"\n Stock of " << ingredient4.getName() << " is :" << ingredient4.getStock() << endl;
                                                cout << "\n Your order has been placed successfully!";
                                            }
                                            else
                                            {
                                                cout << "Not enought stock to satisfy the demand for" << requestedQuantity << " unity." << endl;
                                                cout <<"Let me see if we can add more stock";
                                               
                                                cout << "\n The stock of the lasagna is: ";
                                                cout << "  " << lasagnaIngredients[0].getName() << ": " << lasagnaIngredients[0].getStock() << endl;
                                                cout << "   " <<lasagnaIngredients[1].getName() << ": " << lasagnaIngredients[1].getStock() << endl;
                                                cout << "   " << lasagnaIngredients[2].getName() << ": " <<lasagnaIngredients[2].getStock() << endl;
                                                cout << "   " << lasagnaIngredients[3].getName() << ": " <<lasagnaIngredients[3].getStock() << endl;

                                                int addStock[4];
                                                for (int i = 0; i < 4; i++) {
                                                    cout << "\n Please enter the quantity you want to add for " << lasagnaIngredients[i].getName() << ": ";
                                                    cin >> addStock[i];
                                                }

                                                ingredient1 = ingredient1 + addStock[0];
                                                ingredient2 = ingredient2 + addStock[1];
                                                ingredient3 = ingredient3 + addStock[2];
                                                ingredient4 = ingredient4 + addStock[3];

                                                cout << "\n The new stock is: ";
                                                cout << "  " << lasagnaIngredients[0].getName() << ": " << lasagnaIngredients[0].getStock() << endl;
                                                cout << "   " <<lasagnaIngredients[1].getName() << ": " << lasagnaIngredients[1].getStock() << endl;
                                                cout << "   " <<lasagnaIngredients[2].getName() << ": " << lasagnaIngredients[2].getStock() << endl;
                                                cout << "   " <<lasagnaIngredients[3].getName() << ": " << lasagnaIngredients[3].getStock() << endl;
                                                cout << "\n Your order has been placed successfully!";
                                            }

                                        }
                        }
                        
                }
                else {
                    cout << "\n Order canceled.";
                 }
            } else 
                 if(command == "Menu")
                {
                    cout <<"\n This is the menu of the rastaurant:";
                    cout << "  " << restaurantMenu;
                    restaurantMenu.calculateTotalPrice();
                    cout<<"\n Total price for the meals of the restaurant:"<< restaurantMenu.calculateTotalPrice() << endl;

                } else
                    if(command == "Details_about_restaurant")
                    {
                         Restaurant myRestaurant("Dani's Restaurant", &restaurantMenu, 1, emp, 3, nullptr, 0);
                         cout <<"\n Name of the restaurant: "<< myRestaurant.getName();
                         cout << "\n Employees: ";
                         for(int i = 0; i < 3; i++)
                             cout << " " << emp[i];

                    }
                    else
                        if (command == "Delete_order") {
                    
                        cout << "\n Please enter your full name : ";
                        string clientName;
                        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                        getline(cin, clientName);
                        // vector of clients:
                        Clients client1(1, "Daniela Cotoi", &pizza, restaurantMenu, 1);
                        Clients client2(2, "Andrei Catalin", &burger, restaurantMenu, 1);
                        Clients client3(3, "Maria Ioana", &cake, restaurantMenu, 1);
                        Clients client4(4, "Denisa Elena", &lasagna, restaurantMenu, 1);
                        Clients client[] = {client1, client2, client3, client4};

                        // for(int i = 0; i < 4; i++){
                        //     if(client[i].getName() == clientName){
                        //         client[i].cancelOrder();
                        //         cout << "\n Your order has been canceled successfully!";
                        //     }
                        //     else
                        //         cout << "\n Sorry, we don't have this order in our list";
                        // }

                        if(clientName == "Daniela Cotoi")
                            cout << "\n Your order has been canceled successfully!";
                        else
                            if(clientName == "Andrei Catalin")
                                cout << "\n Your order has been canceled successfully!";
                            else
                                if(clientName == "Maria Ioana")
                                    cout << "\n Your order has been canceled successfully!";
                                else
                                    if(clientName == "Denisa Elena")
                                        cout << "\n Your order has been canceled successfully!";
                                    else
                                        cout << "\n Sorry, we don't have this order in our list";
                        }
                        else 
                            if(command == "Quit") {
                                cout << "\n Thank you for visiting our restaurant!";
                                break;
                            }
                            else
                                cout << "\n Please enter a valid command";

    }
            
}

    

    

        
        

        


    





  
