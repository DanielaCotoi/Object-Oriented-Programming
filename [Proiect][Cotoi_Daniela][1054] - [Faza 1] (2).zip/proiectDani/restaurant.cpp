#include <bits/stdc++.h>
#include<iostream>
#include "Employee.cpp"
#include "clients.cpp"
using namespace std;

class Restaurant
{
private:
    char* name;
    Menu* order;
    int nrOfOrders;
    Employee* employees;
    int nrOfEmployees;
    Clients* clients;
    int nrOfClients;
   // static int anDeschidere;

public:
    Restaurant()
    {
        // this->name = "NoName";
        this->name = new char[strlen("NoName") + 1];
        strcpy(this->name, "NoName");
        this->order = nullptr;
        this->nrOfOrders = 0;
        this->employees = nullptr;
        this->nrOfEmployees = 0;
        this->clients = nullptr;
        this->nrOfClients = 0;
    }

    Restaurant(const char* name)
    {
        if(name != nullptr){
            this->name = new char[strlen(name) + 1];
            strcpy(this->name, name);
            // this->name = name;
        }
        this->order = nullptr;
        this->nrOfOrders = 0;
        this->employees = nullptr;
        this->nrOfEmployees = 0;
        this->clients = nullptr;
        this->nrOfClients = 0;
    }

    Restaurant(const char* name, Menu *order, int nrOfOrders, Employee *employees, int nrOfEmployees, Clients *clients, int nrOfClients)
    {
        if (name != nullptr){
            this->name = new char[strlen(name) + 1];
            strcpy(this->name, name);
        }
        this->nrOfOrders = nrOfOrders > 0 ? nrOfOrders : 0;
        this->order = new Menu[this->nrOfOrders];

        for (int i = 0; i < this->nrOfOrders; i++)
            this->order[i] = order[i];

        this->nrOfEmployees = nrOfEmployees > 0 ? nrOfEmployees : 0;
        this->employees = new Employee[this->nrOfEmployees];
        for (int i = 0; i < this->nrOfEmployees; i++)
            this->employees[i] = employees[i];

        this->nrOfClients = nrOfClients > 0 ? nrOfClients : 0;
        this->clients = new Clients[this->nrOfClients];
        for (int i = 0; i < this->nrOfClients; i++)
            this->clients[i] = clients[i];
    }

    Restaurant(const Restaurant& restaurant)
    {
        if (restaurant.name != nullptr){
            this->name = new char[strlen(restaurant.name) + 1];
            strcpy(this->name, restaurant.name);
        }
        this->nrOfOrders = restaurant.nrOfOrders > 0 ? restaurant.nrOfOrders : 0;
        this->order = new Menu[this->nrOfOrders];

        for (int i = 0; i < this->nrOfOrders; i++)
            this->order[i] = restaurant.order[i];

        this->nrOfEmployees = restaurant.nrOfEmployees > 0 ? restaurant.nrOfEmployees : 0;
        this->employees = new Employee[this->nrOfEmployees];

        for (int i = 0; i < this->nrOfEmployees; i++)
            this->employees[i] = restaurant.employees[i];

        this->nrOfClients = restaurant.nrOfClients > 0 ? restaurant.nrOfClients : 0;
        this->clients = new Clients[this->nrOfClients];
        
        for (int i = 0; i < this->nrOfClients; i++)
            this->clients[i] = restaurant.clients[i];
    }

    Restaurant& operator=(const Restaurant& restaurant)
    {
        if(this != &restaurant) {
            delete[] this->order;
            this->order = nullptr;

            delete[] this->name;
            this->name = nullptr;

            delete[] this->employees;
            this->employees = nullptr;
    
            delete[] this->clients;
            this->clients = nullptr;

            if (restaurant.name != nullptr) {
                this->name = new char[strlen(restaurant.name) + 1];
                strcpy(this->name, restaurant.name);
                // this->name = restaurant.name;
            }
            this->nrOfOrders = restaurant.nrOfOrders > 0 ? restaurant.nrOfOrders : 0;
            this->order = new Menu[this->nrOfOrders];

            for (int i = 0; i < this->nrOfOrders; i++)
                this->order[i] = restaurant.order[i];

            this->nrOfEmployees = restaurant.nrOfEmployees > 0 ? restaurant.nrOfEmployees : 0;
            this->employees = new Employee[this->nrOfEmployees];

            for (int i = 0; i < this->nrOfEmployees; i++)
                this->employees[i] = restaurant.employees[i];

            this->nrOfClients = restaurant.nrOfClients > 0 ? restaurant.nrOfClients : 0;
            this->clients = new Clients[this->nrOfClients];

            for (int i = 0; i < this->nrOfClients; i++)
                this->clients[i] = restaurant.clients[i];
        }

        return *this;        
    }

    const char* getName() {
        return this->name;
    }

    void setName(char* newName) {
        if(newName != nullptr){
            delete[] this->name;
            this->name = new char[strlen(newName) + 1];
            strcpy(this->name, newName);
            // this->name = newName;
        }
    }

    Menu *getOrder() {
        return this->order;
    }

    void setOrder(Menu *newOrder, int newNrOfOrders) {
        this->nrOfOrders = newNrOfOrders > 0 ? newNrOfOrders : 0;
        this->order = new Menu[this->nrOfOrders];
        for (int i = 0; i < this->nrOfOrders; i++)
            this->order[i] = newOrder[i];
    }

    int getNrOfOrders() {
        return this->nrOfOrders;
    }

    void setNrOfOrders(int newNrOfOrders) {
        this->nrOfOrders = (newNrOfOrders > 0) ? newNrOfOrders : 0;
    }

    Employee *getEmployees(){
        return this->employees;
    }

    void setEmployees(Employee *newEmployees, int newnrOfEmployees){
        this->nrOfEmployees = newnrOfEmployees > 0 ? newnrOfEmployees : 0;
        this->employees = new Employee[this->nrOfEmployees];
        for (int i = 0; i < this->nrOfEmployees; i++)
            this->employees[i] = newEmployees[i];
    }

    int getnrOfEmployees(){
        return this->nrOfEmployees;
    }

    void setnrOfEmployees(int newnrOfEmployees){
        this->nrOfEmployees = (newnrOfEmployees > 0) ? newnrOfEmployees : 0;
    }

    Clients *getClients() {
        return this->clients;
    }

    void setClients(Clients *newClients, int newNrOfClients) {
        this->nrOfClients = newNrOfClients > 0 ? newNrOfClients : 0;
        this->clients = new Clients[this->nrOfClients];
        for (int i = 0; i < this->nrOfClients; i++)
            this->clients[i] = newClients[i];
    }

    int getNrOfClients() {
        return this->nrOfClients;
    }

    void setNrOfClients(int newNrOfClients) {
        this->nrOfClients = (newNrOfClients > 0) ? newNrOfClients : 0;
    }

    friend ostream &operator<<(ostream &out, const Restaurant &restaurant)
    {
        out << "\n Name: " << restaurant.name << endl;
        out<<"Number of orders:"<< restaurant.nrOfOrders << endl;
        for(int i = 0; i < restaurant.nrOfOrders; i++){
            out << " " << restaurant.order[i];
        }

        out<<"Number of employees:"<< restaurant.nrOfEmployees << endl;
        out<<"Employees: ";

        for(int i = 0; i < restaurant.nrOfEmployees; i++){
            out << " " << restaurant.employees[i];
        }

        out<<"Number of clients:"<< restaurant.nrOfClients << endl;
        out<<"Clients: ";
            for(int i = 0; i < restaurant.nrOfClients; i++){
                out << " " << restaurant.clients[i];
        }
        return out;
    }
    friend istream &operator>>(istream &in, Restaurant &restaurant)
    {
        cout << "\n Name: ";
        string buffer;
        in >> buffer;
        restaurant.name = new char[buffer.size() + 1];
        strcpy(restaurant.name, buffer.data());

        cout << "\n Number of orders: ";
        in >> restaurant.nrOfOrders;

        for (int i = 0; i < restaurant.nrOfOrders; i++){
            in >> restaurant.order[i];

        }

        cout << "\n Number of employees: ";
        in >> restaurant.nrOfEmployees;
        in.ignore(); // Ignore the newline character

        for (int i = 0; i < restaurant.nrOfEmployees; i++){
            in >> restaurant.employees[i];
            //in.ignore(); // Ignore the newline character
        }

        cout << "\n Number of clients: ";
        in >> restaurant.nrOfClients;
        in.ignore(); // Ignore the newline character

        for (int i = 0; i < restaurant.nrOfClients; i++){
            in >> restaurant.clients[i];
            in.ignore(); // Ignore the newline character
        }
        return in;
    }
    ~Restaurant() {
        delete[]this->name;
        this->name = nullptr;
        delete[]this->order;
        this->order = nullptr;
        delete[] this->employees;
        this->employees = nullptr;
        delete[]this->clients;
        this->clients = nullptr;
    }
};

 //int Restaurant::anDeschidere = 2021;