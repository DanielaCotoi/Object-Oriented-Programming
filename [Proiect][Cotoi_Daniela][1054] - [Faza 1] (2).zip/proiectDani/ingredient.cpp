#include <bits/stdc++.h>

using namespace std;

class Ingredient 
{
private:
    char* name;
    int quantity;
    int stock; // Cantitatea totală de stoc

public:
    Ingredient() {
        this->name = new char[strlen("NoName") + 1];
        strcpy(this->name, "NoName");
        this->quantity = 0;
        this->stock = 0;
    }

    Ingredient(const char* name, int quantity, int stock) {
        if(name != nullptr){
            this->name = new char[strlen(name) + 1];
            strcpy(this->name, name);
            // this->name = name;
        }
        this->quantity = (quantity > 0) ? quantity : 0;
        this->stock = (stock > 0) ? stock : 0;
    }

    Ingredient(const Ingredient &ingredient) {
        if (ingredient.name != nullptr){
            this->name = new char[strlen(ingredient.name) + 1];
            strcpy(this->name, ingredient.name);
        }
        this->quantity = (ingredient.quantity > 0) ? ingredient.quantity : 0;
        this->stock = (ingredient.stock > 0) ? ingredient.stock : 0;
    }

    Ingredient &operator=(const Ingredient &ingredient) {
        if(this != &ingredient){
            delete[] this->name;
            this->name = nullptr;

            if (ingredient.name != nullptr){
                this->name = new char[strlen(ingredient.name) + 1];
                strcpy(this->name, ingredient.name);
            }
            this->quantity = (ingredient.quantity > 0) ? ingredient.quantity : 0;
            this->stock = (ingredient.stock > 0) ? ingredient.stock : 0;
        }
        return *this;
    }

    const char* getName() const {
        return this->name;
    }

    void setName(char* newName) {
        if(newName != nullptr){
            delete[] this->name;
            this->name = new char[strlen(newName) + 1];
            strcpy(this->name, newName);
            // this->name = newName;
        }
    }

    int getQuantity() const { return this->quantity; }

    void setQuantity(int newQuantity) {
        this->quantity = (newQuantity > 0) ? newQuantity : 0;
    }

    int getStock() const { return this->stock; }

    void setStock(int newStock) {
        this->stock = (newStock > 0) ? newStock : 0;
    }

    friend ostream &operator<<(ostream &out, const Ingredient &ingredient)
    {
        out << "Ingredient name: " << ingredient.name << endl;
        out << "Ingredient quantity: " << ingredient.quantity << endl;
        out << "Ingredient stock: " << ingredient.stock << endl;
        return out;
    }

    friend istream &operator>>(istream &in, Ingredient &ingredient)
    {
        cout << "\n Name: ";
        string buffer;
        in >> buffer;
        ingredient.name = new char[buffer.size() + 1];
        strcpy(ingredient.name, buffer.data());

        cout << "Ingredient quantity: ";
        in >> ingredient.quantity;

        cout << "Ingredient stock: ";
        in >> ingredient.stock;

        return in;
    }

    ~Ingredient() {
        delete[] this->name;
        this->name = nullptr;
    }
    bool operator>=(int requestedQuantity){
        if (this->stock >= requestedQuantity) {
            return true;
        } else {
            cout << " " ;
            return false;
        }
    }

    Ingredient &operator-=(int requestedQuantity) 
    {
      if (this->stock >= requestedQuantity) {
            this->stock -= requestedQuantity;
            cout << "The stock are reduced succesfully!" << endl;
    } else {
            cout << " ";
    }
      return *this;
    }

    // overloading la ++(preincrementare)->cresc stocul si dupa afisez
    Ingredient& operator++()
    {
        this->stock++;
        return* this;
    }

    // overloading la --(postdecrementare)->afisez si dupa cresc stocul
    Ingredient operator++(int)
    {
        Ingredient stoc_dupa_incrementare = *this;
        this->stock++;
        return stoc_dupa_incrementare;
    }

    // overloading la --(decrementare)->cresc stocul si dupa afisez
    Ingredient& operator--()
    {
        this->stock--;
        return* this;
    }

    // overloading la --(postdecrementare)->afisez si dupa cresc stocul
    Ingredient operator--(int)
    {
        Ingredient stoc_dupa_decrementare = *this;
        this->stock--;
        return stoc_dupa_decrementare;
    }
    
    Ingredient operator+(int Addstock) { // overloading la + pt a adauga stoc
        if (Addstock > 0) {
            Ingredient result = *this;
            result.stock = this->stock + Addstock;
            return result;
        }
    }
    explicit operator int() {
		return this->stock;
	}
    bool operator!() {
		return !this->stock;
	}

    
};