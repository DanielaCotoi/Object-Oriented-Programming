#include <bits/stdc++.h>
#include "menu.cpp"

using namespace std;


class Clients 
{
private:
    const int idOrder = 0;
    string name;
    Meal* order;
    Menu menu;
    int nrOfOrders;
 public:
    Clients():idOrder(0){
        this->name = "";
        this->order = nullptr;
        this->nrOfOrders = 0;
    }
    const int getIdOrder() {
        return this->idOrder;
    }
    string getName() {
        return this->name;
    }
    void setName(string newName) {
        this->name = (newName.length() > 0) ? newName : "";
    }
    Meal* getOrder() {
        return this->order;
    }
    void setOrder(Meal* newOrder, int newNrOfOrders) {
        if(newOrder != nullptr && newNrOfOrders > 0) {
            this->nrOfOrders = newNrOfOrders;
            this->order = new Meal[this->nrOfOrders];
            for (int i = 0; i < this->nrOfOrders; i++)
                this->order[i] = newOrder[i];
        }
    }
    int getNrOfOrders() {
        return this->nrOfOrders;
    }
    void setNrOfOrders(int newNrOfOrders) {
        this->nrOfOrders = (newNrOfOrders > 0) ? newNrOfOrders : 0;
    }
    Menu getMenu() {
        return this->menu;
    }
    void setMenu(Menu newMenu) {
        this->menu = newMenu;
    }

    Clients(int idOrder, string name, Meal* order, Menu menu, int nrOfOrders)
    :idOrder(idOrder)
    {
        name = (name.length() > 0) ? name : "";
        this->menu = menu;
        if(order != nullptr && nrOfOrders > 0) {
            this->nrOfOrders = nrOfOrders;
            this->order = new Meal[this->nrOfOrders];
            for (int i = 0; i < this->nrOfOrders; i++)
                this->order[i] = order[i];
        }
        else {
            this->order = nullptr;
            this->nrOfOrders = 0;
        }
    }
    Clients(const Clients& client): idOrder(client.idOrder)
    {
        name = (client.name.length() > 0) ? client.name : "";
        this->menu = client.menu;
        if(client.order != nullptr && client.nrOfOrders > 0) {
            this->nrOfOrders = client.nrOfOrders;
            this->order = new Meal[this->nrOfOrders];
            for (int i = 0; i < this->nrOfOrders; i++)
                this->order[i] = client.order[i];
        }
        else {
            this->order = nullptr;
            this->nrOfOrders = 0;
        }
    }

    Clients& operator=(const Clients& client){
        if(this != &client){
            delete[] this->order;
            this->order = nullptr;

            this->name = (client.name.length() > 0) ? client.name : "";
            this->menu = client.menu;
            if (client.order != nullptr && client.nrOfOrders > 0){
                this->nrOfOrders = client.nrOfOrders;
                this->order = new Meal[this->nrOfOrders];
                for (int i = 0; i < this->nrOfOrders; i++)
                    this->order[i] = client.order[i];
            }
            else{
                this->order = nullptr;
                this->nrOfOrders = 0;
            }
        }

        return *this;
    }
    friend ostream &operator<<(ostream &out, const Clients &client)
    {
        out << "\n Id order: " << client.idOrder ;
        out << "\n Name: " << client.name;
        out<<"\n Number of orders:"<< client.nrOfOrders;
            for(int i = 0; i < client.nrOfOrders; i++)
                out << " " << client.order[i];
        out << "\n Menu: " << client.menu;
        return out;
    }
    friend istream &operator>>(istream &in, Clients &client)
    {
        cout << "\n Name: ";
        getline(in, client.name);
        cout << "\n Number of orders: ";
        in >> client.nrOfOrders;
        in.ignore(); // Ignore the newline character

        for(int i = 0; i < client.nrOfOrders; i++){
            in >> client.order[i];
            in.ignore(); // Ignore the newline character
        }
        cout << "\n Menu: ";
        in >> client.menu;
        return in;
    }
    bool operator!=(const Clients& client){
        if(this->idOrder != client.idOrder){
            return true;
        }
        return false;
    }
    // void cancelOrder(){
    //     if(this->order != nullptr){
    //         for(int i = 0; i < this->nrOfOrders; i++){
    //             this->order[i] = Meal();
    //         }
    //         cout << "The order was canceled succesfully!" << endl;
    //     } else {
    //         cout << "There is no order to cancel." << endl;
    //     }
    // }
    // void cancelOrderByName(const string& clientName) {
    // bool found = false;
    // for (int i = 0; i < this->nrOfOrders; i++) {
    //     if (this->order[i].getName() == clientName) {
    //         this->order[i].cancelOrder();
    //         found = true;
    //         break;
    //     }
    // }

    // if (!found) {
    //     cout << "Clientul cu numele " << clientName << " nu a fost găsit." << endl;
    // } else {
    //     cout << "Comanda clientului " << clientName << " a fost anulată cu succes!" << endl;
    // }


    

    ~Clients() {
        delete[]this->order;
        this->order = nullptr;
    }
};


    
